class Persona {
  final String nombre;
  final String email;
  final String telefono;
  final String password;

  Persona(
      {required this.nombre,
      required this.email,
      required this.telefono,
      required this.password});
}
